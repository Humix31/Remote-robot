/* VOLT cloud robot controller.
   Install libraries: WebSockets (Markus Sattler) and ArduinoJson (Benoit Blanchon).
   Set Wi-Fi credentials and Render hostname below. ESP32 needs internet access.
   GPIO map is assumed; verify board wiring, common GND, motor supply, and STBY HIGH.
*/
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include <math.h>
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* BACKEND_HOST = "YOUR-RENDER-SERVICE.onrender.com"; // hostname only
const uint16_t BACKEND_PORT = 443;
const char* BACKEND_PATH = "/robot";
#define PWMA 18
#define AIN1 4
#define AIN2 25
#define PWMB 23
#define BIN1 13
#define BIN2 19
const unsigned long TIMEOUT_MS=700;
WebSocketsClient webSocket; unsigned long lastCmd=0,lastStatus=0; bool moving=false;
void leftMotor(int v){v=constrain(v,-255,255);digitalWrite(AIN1,v>0);digitalWrite(AIN2,v<0);ledcWrite(PWMA,abs(v));}
void rightMotor(int v){v=constrain(v,-255,255);digitalWrite(BIN1,v>0);digitalWrite(BIN2,v<0);ledcWrite(PWMB,abs(v));}
void stopMotors(){leftMotor(0);rightMotor(0);moving=false;}
void drive(int x,int y,int speed){x=constrain(x,-100,100);y=constrain(y,-100,100);speed=constrain(speed,0,255);float l=y+x,r=y-x,m=max(fabsf(l),fabsf(r));if(m>100){l=l*100/m;r=r*100/m;}int lv=roundf(l*speed/100),rv=roundf(r*speed/100);leftMotor(lv);rightMotor(rv);lastCmd=millis();moving=(lv!=0||rv!=0);}
void onWs(WStype_t type,uint8_t* payload,size_t len){if(type==WStype_CONNECTED){Serial.println("Cloud backend connected");}else if(type==WStype_DISCONNECTED){Serial.println("Cloud backend disconnected");stopMotors();}else if(type==WStype_TEXT){StaticJsonDocument<256>d;if(deserializeJson(d,payload,len))return;const char* cmd=d["type"]|"";if(!strcmp(cmd,"move"))drive(d["x"]|0,d["y"]|0,d["speed"]|0);else if(!strcmp(cmd,"stop")){stopMotors();lastCmd=millis();Serial.println("STOP received");}}}
void setup(){Serial.begin(115200);pinMode(AIN1,OUTPUT);pinMode(AIN2,OUTPUT);pinMode(BIN1,OUTPUT);pinMode(BIN2,OUTPUT);ledcAttach(PWMA,1000,8);ledcAttach(PWMB,1000,8);stopMotors();WiFi.mode(WIFI_STA);WiFi.setSleep(false);WiFi.begin(WIFI_SSID,WIFI_PASSWORD);Serial.print("Connecting to Wi-Fi");unsigned long start=millis();while(WiFi.status()!=WL_CONNECTED&&millis()-start<20000){delay(500);Serial.print('.');}Serial.println();if(WiFi.status()!=WL_CONNECTED){Serial.println("Wi-Fi failed: check credentials and use a 2.4 GHz network");return;}Serial.print("Wi-Fi connected, IP: ");Serial.println(WiFi.localIP());webSocket.beginSSL(BACKEND_HOST,BACKEND_PORT,BACKEND_PATH);webSocket.setInsecure();webSocket.onEvent(onWs);webSocket.setReconnectInterval(5000);webSocket.enableHeartbeat(15000,3000,2);}
void loop(){if(WiFi.status()!=WL_CONNECTED){stopMotors();delay(10);return;}webSocket.loop();if(moving&&millis()-lastCmd>TIMEOUT_MS){stopMotors();Serial.println("Safety timeout: stopped");}if(millis()-lastStatus>5000){lastStatus=millis();StaticJsonDocument<96>d;d["type"]="robot_status";d["connected"]=true;String s;serializeJson(d,s);webSocket.sendTXT(s);}delay(2);}
